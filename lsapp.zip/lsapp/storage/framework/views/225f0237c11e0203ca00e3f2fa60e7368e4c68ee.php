

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($title); ?></h1>
    <p>This is the Laravel application from the "Laravel from Scratch" You tube series Traversy</p>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('pages.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/index.blade.php ENDPATH**/ ?>