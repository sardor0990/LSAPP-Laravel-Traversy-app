

<?php $__env->startSection('content'); ?>
    <base target="_blank"> <!--ozim sinov uchun yozdim bu blank ochadi-->
    
    <h1><?php echo e($title); ?></h1>
    
    <em><?php echo e($description); ?></em>
    
    <?php if(count($services) >  0): ?>
        <ul>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($service); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <a href="about">asd</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/pages/services.blade.php ENDPATH**/ ?>