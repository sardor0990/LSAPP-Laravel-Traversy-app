@extends('pages.layouts.app')

@section('content')
    <h1><?php echo $title ?></h1>
    <p>this is about page</p>
@endsection
