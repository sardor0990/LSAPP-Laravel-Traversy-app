@extends('pages.layouts.app')

@section('content')
    <h1>{{$title}}</h1>
    <p>This is the Laravel application from the "Laravel from Scratch" You tube series Traversy</p>
@endsection  